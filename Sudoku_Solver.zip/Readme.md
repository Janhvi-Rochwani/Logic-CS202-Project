Question 1:
The source code is 'Q1_CS202_A1.py'
The test cases are provided in the folder 'tests'
The parameter k should be given as input to the terminal by the tester themselves as mentioned in question 
There are 5 test cases, for k = 2,3,4,5,6

The csv test file for different values of k are named as sudoku_with_dimensions_k.csv. For example, the csv file input for k=2 is named as sudoku_with_dimensions_2.csv

The expected outputs of each test case are sudoku_with_dimensions_k_output.csv

Question 2:
The source code is 'Q2_CS202_A1.py'

The parameter k should be given as input to the terminal by the tester themselves as mentioned in question 

The output (maximal sudoku pair) will be written to Q2_output.csv file